description: weather data from INMET
range date: 2019/09/01 to 2019/09/07
sensors: radiacao,vento_rajada,vento_direcao,umid_max,umid_min,temp_max,pressao,pressao_min,pto_orvalho_inst,pto_orvalho_max,vento_vel,temp_min,pressao_max,pto_orvalho_min,temp_inst,umid_inst,precipitacao